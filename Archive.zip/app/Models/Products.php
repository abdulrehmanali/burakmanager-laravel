<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    use HasFactory;
    protected $fillable = [
      'name',
      'shop_id',
      'sku'
    ];
    public function batches() {
      return $this->hasMany(ProductsBatches::class,'product_id');
    }
}
