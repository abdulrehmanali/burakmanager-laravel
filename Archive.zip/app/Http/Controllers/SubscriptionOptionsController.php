<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubscriptionOptionsController extends Controller
{
    //
}
