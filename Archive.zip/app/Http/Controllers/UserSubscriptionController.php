<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserSubscriptionController extends Controller
{
  public function FunctionName()
  {
    
  }
}
